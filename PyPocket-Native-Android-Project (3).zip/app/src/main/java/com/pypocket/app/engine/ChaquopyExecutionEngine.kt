package com.pypocket.app.engine

import android.content.Context
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Concrete Android implementation using the Chaquopy embedded CPython engine.
 *
 * Genuine execution pipeline:
 * 1. Checks if Python runtime is initialized via [com.chaquo.python.Python].
 * 2. If runtime is not initialized, starts Python via AndroidPlatform.
 * 3. Dispatches the script to `pypocket_runner.py` which executes the code in an
 *    isolated namespace with stdout/stderr redirection.
 * 4. Captures genuine standard output, execution duration, and Python exceptions.
 * 5. Returns [ExecutionResult.Success], [ExecutionResult.Error], or [ExecutionResult.RuntimeNotConfigured].
 */
class ChaquopyExecutionEngine(
    private val context: Context,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) : PythonExecutionEngine {

    override val engineName: String = "Chaquopy Embedded Python 3.11"

    override val isRuntimeReady: Boolean
        get() = try {
            Class.forName("com.chaquo.python.Python")
            true
        } catch (e: Throwable) {
            false
        }

    private val _executionState = MutableStateFlow<ExecutionResult>(ExecutionResult.Idle)
    override val executionState: StateFlow<ExecutionResult> = _executionState.asStateFlow()

    override suspend fun execute(code: String): ExecutionResult = withContext(dispatcher) {
        _executionState.value = ExecutionResult.Running

        // Validate empty input early
        if (code.isBlank()) {
            val emptyResult = ExecutionResult.Error(
                stderr = "PyPocket Notice: Cannot execute an empty script. Please write some Python code first.",
                errorType = "EmptyInputError",
                executionTimeMs = 0
            )
            _executionState.value = emptyResult
            return@withContext emptyResult
        }

        if (!isRuntimeReady) {
            val unconfigured = ExecutionResult.RuntimeNotConfigured(
                engineName = engineName,
                reason = "Chaquopy embedded CPython runtime libraries are not present in this JVM classpath.",
                setupInstructions = """
                    To run Python natively on your Android device:
                    1. Sync the project with Gradle in Android Studio.
                    2. The Chaquopy plugin is configured in build.gradle.kts and app/build.gradle.kts.
                    3. Run the app on an Android device or emulator with API 26+.
                """.trimIndent()
            )
            _executionState.value = unconfigured
            return@withContext unconfigured
        }

        try {
            val pythonClass = Class.forName("com.chaquo.python.Python")
            val isStartedMethod = pythonClass.getMethod("isStarted")
            val isStarted = isStartedMethod.invoke(null) as Boolean

            if (!isStarted) {
                val androidPlatformClass = Class.forName("com.chaquo.python.android.AndroidPlatform")
                val platformConstructor = androidPlatformClass.getConstructor(Context::class.java)
                val platformInstance = platformConstructor.newInstance(context)

                val startMethod = pythonClass.getMethod("start", Class.forName("com.chaquo.python.PythonPlatform"))
                startMethod.invoke(null, platformInstance)
            }

            val getInstanceMethod = pythonClass.getMethod("getInstance")
            val pyInstance = getInstanceMethod.invoke(null)

            val getModuleMethod = pythonClass.getMethod("getModule", String::class.java)
            val runnerModule = getModuleMethod.invoke(pyInstance, "pypocket_runner")

            val pyObjectClass = Class.forName("com.chaquo.python.PyObject")
            val callAttrMethod = pyObjectClass.getMethod("callAttr", String::class.java, Array<Any>::class.java)

            // Invoke run_code(code)
            val resultPyObject = callAttrMethod.invoke(runnerModule, "run_code", arrayOf<Any>(code))

            // Extract map items
            val getMethod = pyObjectClass.getMethod("get", Any::class.java)
            val stdoutObj = getMethod.invoke(resultPyObject, "stdout")
            val stderrObj = getMethod.invoke(resultPyObject, "stderr")
            val exitCodeObj = getMethod.invoke(resultPyObject, "exit_code")
            val durationObj = getMethod.invoke(resultPyObject, "duration_ms")
            val hasErrorObj = getMethod.invoke(resultPyObject, "has_error")

            val stdout = stdoutObj?.toString() ?: ""
            val stderr = stderrObj?.toString() ?: ""
            val exitCode = (exitCodeObj?.toString()?.toIntOrNull()) ?: 0
            val durationMs = (durationObj?.toString()?.toLongOrNull()) ?: 0L
            val hasError = (hasErrorObj?.toString()?.toBooleanStrictOrNull()) ?: false

            val finalResult = if (hasError || exitCode != 0 || stderr.isNotBlank()) {
                ExecutionResult.Error(
                    stderr = stderr.ifBlank { "Execution finished with exit code $exitCode" },
                    errorType = if (stderr.contains("SyntaxError")) "SyntaxError" else "RuntimeError",
                    executionTimeMs = durationMs
                )
            } else {
                ExecutionResult.Success(
                    stdout = stdout,
                    executionTimeMs = durationMs,
                    exitCode = exitCode
                )
            }

            _executionState.value = finalResult
            finalResult

        } catch (e: Throwable) {
            val rootCause = e.cause ?: e
            val errorMessage = rootCause.localizedMessage ?: rootCause.message ?: "Python Execution Error"

            val errorResult = ExecutionResult.Error(
                stderr = errorMessage,
                errorType = rootCause.javaClass.simpleName,
                executionTimeMs = 0
            )
            _executionState.value = errorResult
            errorResult
        }
    }

    override fun resetConsole() {
        _executionState.value = ExecutionResult.Idle
    }
}
