package com.pypocket.app

import android.app.Application
import com.pypocket.app.data.repository.FileProgramRepository
import com.pypocket.app.data.repository.ProgramRepository
import com.pypocket.app.engine.ChaquopyExecutionEngine
import com.pypocket.app.engine.PythonExecutionEngine

/**
 * Main Application container providing lightweight Dependency Injection
 * for repository and execution engine instances.
 */
class PyPocketApp : Application() {

    lateinit var programRepository: ProgramRepository
        private set

    lateinit var executionEngine: PythonExecutionEngine
        private set

    override fun onCreate() {
        super.onCreate()
        programRepository = FileProgramRepository(applicationContext)
        executionEngine = ChaquopyExecutionEngine(applicationContext)
    }
}
