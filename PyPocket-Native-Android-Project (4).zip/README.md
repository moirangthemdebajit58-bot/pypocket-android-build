# PyPocket (Native Android) 🐍📱

PyPocket is a beginner-friendly native Android Python code editor and runner built with **Kotlin**, **Jetpack Compose**, and **Material 3**.

---

## 📁 Native Android Project File Structure

```text
android/
├── build.gradle.kts                            # Root Gradle build script
├── settings.gradle.kts                         # Subproject inclusion & plugin repositories
├── gradle/wrapper/gradle-wrapper.properties    # Gradle 8.7 wrapper configuration
└── app/
    ├── build.gradle.kts                        # Module build file (Kotlin 2.0, Compose BOM, Serialization)
    ├── src/
    │   ├── main/
    │   │   ├── AndroidManifest.xml             # No unnecessary permissions or telemetry
    │   │   ├── python/
    │   │   │   └── pypocket_runner.py          # Embedded Python runner executing user scripts & capturing IO
    │   │   ├── res/values/
    │   │   │   ├── strings.xml                 # UI strings and runtime notices
    │   │   │   ├── colors.xml                  # Color tokens
    │   │   │   └── themes.xml                  # App theme
    │   │   └── java/com/pypocket/app/
    │   │       ├── PyPocketApp.kt              # Application subclass (DI for Repository & Engine)
    │   │       ├── MainActivity.kt             # Navigation Host & Entry Activity
    │   │       ├── data/
    │   │       │   ├── model/
    │   │       │   │   ├── PythonProgram.kt    # Immutable program document entity
    │   │       │   │   └── ExamplePrograms.kt  # Hello World, Calculator, Multiplication Table
    │   │       │   └── repository/
    │   │       │       ├── ProgramRepository.kt     # Storage abstraction
    │   │       │       └── FileProgramRepository.kt # Local JSON persistence in internal filesDir
    │   │       ├── engine/
    │   │       │   ├── PythonExecutionEngine.kt    # Python runner abstraction
    │   │       │   ├── ExecutionResult.kt          # Success, Error, RuntimeNotConfigured, Idle, Running
    │   │       │   └── ChaquopyExecutionEngine.kt  # Chaquopy bridge invoking pypocket_runner.py
    │   │       └── ui/
    │   │           ├── navigation/Screen.kt        # Compose navigation routes
    │   │           ├── theme/                      # Material 3 colors, typography, theme
    │   │           │   ├── Color.kt
    │   │           │   ├── Type.kt
    │   │           │   └── Theme.kt
    │   │           ├── home/                       # Home screen & list of programs
    │   │           │   ├── HomeScreen.kt
    │   │           │   └── HomeViewModel.kt
    │   │           └── editor/                     # Code editor, helper bar & console bottom sheet
    │   │               ├── EditorScreen.kt
    │   │               ├── EditorViewModel.kt
    │   │               └── ConsoleBottomSheet.kt
    │   └── test/java/com/pypocket/app/
    │       ├── ProgramRepositoryTest.kt            # Unit tests for CRUD and Duplication
    │       └── PythonExecutionEngineTest.kt        # Tests verifying unconfigured state compliance
```

---

## 🛠️ Implemented Features (MVP)

1. **Home Screen**:
   - List of saved Python scripts with line count and timestamp badges.
   - New Program dialog.
   - Search filter across script titles, descriptions, and code contents.
   - Program card options (Duplicate, Delete, Open).
   - "Restore Examples" button.
   - Clean empty states and error boundaries.

2. **Python Editor Screen**:
   - Dark theme code editor with line number gutter.
   - Monospaced typography with configurable cursor brush.
   - Quick Python helper toolbar (Tab indentation 4 spaces, `def`, `if`, `for`, `print()`, `:`, `()`, etc.).
   - Persistent title renaming directly from the top bar.
   - Save button with visual state feedback and auto-save on navigation.
   - Copy code to Android clipboard.

3. **Output Console**:
   - Modal bottom sheet displaying Standard Output (stdout), Errors/Traceback (stderr), and Execution Diagnostics.
   - Copy console output action.
   - Clear console action.
   - Status badge indicators (`RUNNING`, `SUCCESS`, `ERROR`, `UNCONFIGURED`).

4. **Local Program Storage**:
   - `FileProgramRepository` reads and writes to private internal app storage (`context.filesDir/pypocket_programs.json`) via `kotlinx.serialization.json`.
   - Never requests external SD card permissions or contacts.
   - Self-seeds default example programs on fresh launch.

5. **Example Programs**:
   - **Hello World**: Formatted strings, list iteration, greeting functions.
   - **Pocket Calculator**: Arithmetic helper functions, division by zero guard, floating-point formatting.
   - **Multiplication Table**: Nested loops and tabular number formatting.

6. **Engineering Rules Compliance**:
   - **No fake execution results**: `ChaquopyExecutionEngine` checks if the embedded Python runtime is bundled on the classpath.
   - If not bundled, it renders an honest **"Python Runtime Not Configured"** notice with step-by-step instructions rather than fabricated output.

---

## ⚙️ Building & Running in Android Studio

### Prerequisites
- Android Studio Iguana / Jellyfish / Koala (or newer)
- Android SDK 34 (Android 14) installed
- JDK 17 configured in Android Studio

### Build Steps
1. Open Android Studio -> **Open...** -> select the `android` directory.
2. Allow Gradle sync to complete (`./gradlew assembleDebug`).
3. Run the unit tests:
   ```bash
   ./gradlew testDebugUnitTest
   ```
4. Run on an Android Emulator or physical device (API 26+).

---

## 🔌 Connecting a Real Embedded Python Runtime (Chaquopy)

To enable live local Python execution on your Android device:

1. In `android/build.gradle.kts`, add:
   ```kotlin
   plugins {
       id("com.chaquo.python") version "15.0.1" apply false
   }
   ```
2. In `android/app/build.gradle.kts`, apply the plugin and configure:
   ```kotlin
   plugins {
       id("com.chaquo.python")
   }

   android {
       defaultConfig {
           ndk {
               abiFilters += listOf("arm64-v8a", "x86_64")
           }
       }
   }

   chaquopy {
       defaultConfig {
           version = "3.11"
           pip {
               // install("numpy")
           }
       }
   }
   ```
3. Re-sync Gradle in Android Studio. `ChaquopyExecutionEngine.isRuntimeReady` will automatically evaluate to `true` and run code locally via CPython!
