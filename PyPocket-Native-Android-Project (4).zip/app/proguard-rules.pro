# ProGuard rules for PyPocket Native Android App

# Keep Chaquopy classes from being stripped during minification
-keep class com.chaquo.python.** { *; }
-dontwarn com.chaquo.python.**

# Keep kotlinx serialization models
-keepclassmembers class * {
    *** Companion;
}
-keepclasseswithmembers class * {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep Compose animation and runtime internal properties
-keepclassmembers class androidx.compose.ui.platform.InspectableValue {
    *;
}
