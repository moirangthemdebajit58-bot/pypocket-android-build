package com.pypocket.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.pypocket.app.data.model.ExamplePrograms
import com.pypocket.app.data.model.PythonProgram
import com.pypocket.app.data.repository.ProgramRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface HomeUiState {
    object Loading : HomeUiState
    data class Success(
        val programs: List<PythonProgram>,
        val searchQuery: String = ""
    ) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

class HomeViewModel(
    private val repository: ProgramRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val uiState: StateFlow<HomeUiState> = combine(
        repository.getAllPrograms(),
        _searchQuery
    ) { programs, query ->
        val filtered = if (query.isBlank()) {
            programs
        } else {
            programs.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.code.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true)
            }
        }
        HomeUiState.Success(programs = filtered, searchQuery = query)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState.Loading
    )

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun createNewProgram(title: String = "Untitled Script", onCreated: (String) -> Unit) {
        viewModelScope.launch {
            val id = "prog_${System.currentTimeMillis()}"
            val newProg = PythonProgram(
                id = id,
                title = title.ifBlank { "Untitled Script" },
                code = "# PyPocket Python Script\n\ndef main():\n    print(\"Hello from PyPocket!\")\n\nif __name__ == \"__main__\":\n    main()\n"
            )
            repository.saveProgram(newProg)
            onCreated(id)
        }
    }

    fun deleteProgram(id: String) {
        viewModelScope.launch {
            repository.deleteProgram(id)
        }
    }

    fun duplicateProgram(id: String) {
        viewModelScope.launch {
            repository.duplicateProgram(id)
        }
    }

    fun restoreExamples() {
        viewModelScope.launch {
            ExamplePrograms.all.forEach {
                repository.saveProgram(it)
            }
        }
    }

    companion object {
        fun provideFactory(repository: ProgramRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return HomeViewModel(repository) as T
                }
            }
    }
}
