package com.pypocket.app

import android.app.Application
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.pypocket.app.data.repository.FileProgramRepository
import com.pypocket.app.data.repository.ProgramRepository
import com.pypocket.app.engine.ChaquopyExecutionEngine
import com.pypocket.app.engine.PythonExecutionEngine

/**
 * Main Application container providing lightweight Dependency Injection
 * for repository and execution engine instances.
 * Also performs early initialization of the Chaquopy embedded runtime.
 */
class PyPocketApp : Application() {

    lateinit var programRepository: ProgramRepository
        private set

    lateinit var executionEngine: PythonExecutionEngine
        private set

    override fun onCreate() {
        super.onCreate()
        programRepository = FileProgramRepository(applicationContext)
        executionEngine = ChaquopyExecutionEngine(applicationContext)

        // Initialize Python runtime early during application startup
        initializePythonRuntime()
    }

    private fun initializePythonRuntime() {
        try {
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(this))
                Log.i("PyPocketApp", "Chaquopy embedded Python runtime initialized successfully.")
            }
        } catch (e: Throwable) {
            // Handled gracefully in host JVM testing; logged for Android device debugging
            Log.e("PyPocketApp", "Chaquopy runtime start notice: ${e.message}", e)
        }
    }
}
