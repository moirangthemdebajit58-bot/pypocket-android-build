package com.pypocket.app.data.repository

import com.pypocket.app.data.model.PythonProgram
import kotlinx.coroutines.flow.Flow

/**
 * Storage contract for persisting and retrieving user Python programs.
 */
interface ProgramRepository {
    fun getAllPrograms(): Flow<List<PythonProgram>>
    suspend fun getProgramById(id: String): PythonProgram?
    suspend fun saveProgram(program: PythonProgram): Result<Unit>
    suspend fun deleteProgram(id: String): Result<Unit>
    suspend fun duplicateProgram(id: String): Result<PythonProgram>
}
