package com.pypocket.app.data.model

import kotlinx.serialization.Serializable

/**
 * Represents a saved or in-memory Python program document.
 */
@Serializable
data class PythonProgram(
    val id: String,
    val title: String,
    val code: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val description: String = ""
) {
    val lineCount: Int
        get() = code.split("\n").size
}
