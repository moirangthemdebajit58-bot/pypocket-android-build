package com.pypocket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pypocket.app.ui.editor.EditorScreen
import com.pypocket.app.ui.editor.EditorViewModel
import com.pypocket.app.ui.home.HomeScreen
import com.pypocket.app.ui.home.HomeViewModel
import com.pypocket.app.ui.navigation.Screen
import com.pypocket.app.ui.theme.PyPocketTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as PyPocketApp
        val repository = app.programRepository
        val executionEngine = app.executionEngine

        setContent {
            PyPocketTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route
                    ) {
                        composable(Screen.Home.route) {
                            val homeViewModel: HomeViewModel = viewModel(
                                factory = HomeViewModel.provideFactory(repository)
                            )
                            HomeScreen(
                                viewModel = homeViewModel,
                                onNavigateToEditor = { programId ->
                                    navController.navigate(Screen.Editor.createRoute(programId))
                                }
                            )
                        }

                        composable(
                            route = Screen.Editor.route,
                            arguments = listOf(navArgument("programId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val programId = backStackEntry.arguments?.getString("programId") ?: ""
                            val editorViewModel: EditorViewModel = viewModel(
                                key = programId,
                                factory = EditorViewModel.provideFactory(
                                    programId = programId,
                                    repository = repository,
                                    executionEngine = executionEngine
                                )
                            )
                            EditorScreen(
                                viewModel = editorViewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
