package com.pypocket.app.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pypocket.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Synchronize editor text with cursor support
    var textFieldValue by remember {
        mutableStateOf(TextFieldValue(uiState.code))
    }

    // Keep internal text state synchronized when initial program is loaded
    LaunchedEffect(uiState.code) {
        if (textFieldValue.text != uiState.code) {
            textFieldValue = textFieldValue.copy(text = uiState.code)
        }
    }

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = {
                        if (uiState.isDirty) {
                            viewModel.saveProgram()
                        }
                        onNavigateBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    BasicTextField(
                        value = uiState.title,
                        onValueChange = { viewModel.onTitleChange(it) },
                        textStyle = MaterialTheme.typography.titleMedium.copy(color = DarkOnSurface),
                        cursorBrush = SolidColor(EmeraldPrimary),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    // Save action
                    IconButton(onClick = { viewModel.saveProgram() }) {
                        Icon(
                            imageVector = if (uiState.isDirty) Icons.Default.Save else Icons.Default.Done,
                            tint = if (uiState.isDirty) EmeraldPrimary else DarkOnSurfaceVariant,
                            contentDescription = "Save"
                        )
                    }

                    // Copy code action
                    IconButton(onClick = {
                        clipboardManager.setText(AnnotatedString(uiState.code))
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code")
                    }

                    // Open console drawer manually
                    IconButton(onClick = { viewModel.setConsoleOpen(true) }) {
                        Icon(Icons.Default.Terminal, contentDescription = "View Console")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface
                )
            )
        },
        floatingActionButton = {
            // Thumb-friendly Run Button on mobile
            ExtendedFloatingActionButton(
                onClick = { viewModel.runCode() },
                icon = {
                    if (uiState.isExecuting) {
                        CircularProgressIndicator(
                            color = EmeraldOnPrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                    }
                },
                text = {
                    Text(
                        text = if (uiState.isExecuting) "Running..." else "Run",
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = EmeraldPrimary,
                contentColor = EmeraldOnPrimary,
                modifier = Modifier.padding(bottom = 44.dp) // Leave space above the quick indent toolbar
            )
        },
        bottomBar = {
            // Quick Python Mobile Helper & Indentation Toolbar
            PythonHelperToolbar(
                onInsertSnippet = { snippet ->
                    val (newText, newCursor) = viewModel.insertTextAtSelection(
                        currentText = textFieldValue.text,
                        selectionStart = textFieldValue.selection.start,
                        selectionEnd = textFieldValue.selection.end,
                        textToInsert = snippet
                    )
                    textFieldValue = TextFieldValue(
                        text = newText,
                        selection = TextRange(newCursor)
                    )
                },
                onIndent = {
                    val (newText, newCursor) = viewModel.insertIndentation(
                        currentText = textFieldValue.text,
                        cursorIndex = textFieldValue.selection.start
                    )
                    textFieldValue = TextFieldValue(
                        text = newText,
                        selection = TextRange(newCursor)
                    )
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(EditorGutter)
        ) {
            if (uiState.isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                    color = EmeraldPrimary
                )
            } else {
                val verticalScroll = rememberScrollState()
                val lineCount = remember(textFieldValue.text) {
                    textFieldValue.text.split("\n").size.coerceAtLeast(1)
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(verticalScroll)
                ) {
                    // Line numbers gutter
                    Column(
                        modifier = Modifier
                            .width(42.dp)
                            .background(EditorGutter)
                            .padding(vertical = 12.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        for (i in 1..lineCount) {
                            Text(
                                text = "$i",
                                style = MonospaceEditorTypography.copy(
                                    color = EditorLineNumber,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }

                    // Main Monospace Code Input Area
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(DarkBackground)
                            .padding(12.dp)
                    ) {
                        BasicTextField(
                            value = textFieldValue,
                            onValueChange = {
                                textFieldValue = it
                                viewModel.onCodeChange(it.text)
                            },
                            textStyle = MonospaceEditorTypography.copy(
                                color = EditorText
                            ),
                            cursorBrush = SolidColor(EmeraldPrimary),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // Modal Output Console
    if (uiState.isConsoleOpen) {
        ConsoleBottomSheet(
            result = uiState.executionResult,
            isExecuting = uiState.isExecuting,
            onClear = { viewModel.clearConsole() },
            onDismiss = { viewModel.setConsoleOpen(false) }
        )
    }
}

@Composable
fun PythonHelperToolbar(
    onInsertSnippet: (String) -> Unit,
    onIndent: () -> Unit
) {
    val quickItems = listOf(
        "TAB" to { onIndent() },
        ":" to { onInsertSnippet(":") },
        "(" to { onInsertSnippet("()") },
        "\"" to { onInsertSnippet("\"\"") },
        "'" to { onInsertSnippet("''") },
        "=" to { onInsertSnippet(" = ") },
        "def" to { onInsertSnippet("def ") },
        "if" to { onInsertSnippet("if ") },
        "for" to { onInsertSnippet("for ") },
        "in" to { onInsertSnippet(" in ") },
        "print" to { onInsertSnippet("print()") },
        "return" to { onInsertSnippet("return ") },
        "#" to { onInsertSnippet("# ") }
    )

    Surface(
        color = DarkSurfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickItems.forEach { (label, action) ->
                FilledTonalButton(
                    onClick = action,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = DarkSurface,
                        contentColor = DarkOnSurface
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontFamily = MonospaceEditorTypography.fontFamily
                    )
                }
            }
        }
    }
}
