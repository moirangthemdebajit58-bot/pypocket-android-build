package com.pypocket.app.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldOnPrimary = Color(0xFF022C22)
val EmeraldPrimaryContainer = Color(0xFF064E3B)
val EmeraldOnPrimaryContainer = Color(0xFFA7F3D0)

val DarkBackground = Color(0xFF0F1117)
val DarkSurface = Color(0xFF161922)
val DarkSurfaceVariant = Color(0xFF1E222D)
val DarkOutline = Color(0xFF2E3440)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

val ConsoleBackground = Color(0xFF0B0D13)
val ConsoleStdout = Color(0xFFF8FAFC)
val ConsoleStderr = Color(0xFFF87171)
val ConsoleWarning = Color(0xFFFBBF24)
val ConsoleSuccess = Color(0xFF34D399)

val EditorGutter = Color(0xFF141720)
val EditorLineNumber = Color(0xFF475569)
val EditorText = Color(0xFFF1F5F9)
val EditorSelection = Color(0x3310B981)
