package com.pypocket.app.ui.editor

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pypocket.app.engine.ExecutionResult
import com.pypocket.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleBottomSheet(
    result: ExecutionResult,
    isExecuting: Boolean,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    var showFullTraceback by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = ConsoleBackground,
        dragHandle = { BottomSheetDefaults.DragHandle(color = DarkOutline) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp)
        ) {
            // Header bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Console Output",
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkOnSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(result = result, isExecuting = isExecuting)
                }

                Row {
                    IconButton(
                        onClick = {
                            val textToCopy = when (result) {
                                is ExecutionResult.Success -> result.stdout
                                is ExecutionResult.Error -> result.stderr
                                is ExecutionResult.RuntimeNotConfigured -> "${result.reason}\n\n${result.setupInstructions}"
                                else -> ""
                            }
                            if (textToCopy.isNotEmpty()) {
                                clipboardManager.setText(AnnotatedString(textToCopy))
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Output",
                            tint = DarkOnSurfaceVariant
                        )
                    }
                    IconButton(onClick = onClear) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Clear Console",
                            tint = DarkOnSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Console Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp, max = 360.dp)
                    .background(DarkSurface, shape = RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                if (isExecuting) {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = EmeraldPrimary,
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Executing Python code...",
                            color = DarkOnSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                } else {
                    val verticalScroll = rememberScrollState()
                    val horizontalScroll = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(verticalScroll)
                            .horizontalScroll(horizontalScroll)
                    ) {
                        when (result) {
                            is ExecutionResult.Idle -> {
                                Text(
                                    text = "Ready. Tap Run to execute your Python script.",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = DarkOnSurfaceVariant
                                )
                            }
                            is ExecutionResult.Success -> {
                                if (result.stdout.isBlank()) {
                                    Text(
                                        text = "(Execution finished with exit code 0 and no output)",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        color = DarkOnSurfaceVariant
                                    )
                                } else {
                                    Text(
                                        text = result.stdout,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        color = ConsoleStdout,
                                        lineHeight = 20.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Process finished in ${result.executionTimeMs}ms with exit code ${result.exitCode}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = ConsoleSuccess
                                )
                            }
                            is ExecutionResult.Error -> {
                                val lineMatch = Regex("""line\s+(\d+)""", RegexOption.IGNORE_CASE).find(result.stderr)
                                val lineNum = lineMatch?.groupValues?.getOrNull(1)

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = ConsoleStderr.copy(alpha = 0.12f),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.ErrorOutline,
                                                    contentDescription = null,
                                                    tint = ConsoleStderr,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = result.errorType.ifBlank { "Execution Error" },
                                                    fontWeight = FontWeight.Bold,
                                                    color = ConsoleStderr,
                                                    fontSize = 13.sp
                                                )
                                            }
                                            if (lineNum != null) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = ConsoleStderr.copy(alpha = 0.2f)
                                                ) {
                                                    Text(
                                                        text = "Line $lineNum",
                                                        color = ConsoleStderr,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        val conciseMsg = result.stderr.lines().lastOrNull { it.isNotBlank() } ?: result.stderr
                                        Text(
                                            text = conciseMsg,
                                            fontSize = 12.sp,
                                            color = DarkOnSurface,
                                            fontFamily = FontFamily.Monospace
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Expandable full traceback
                                        Row(
                                            modifier = Modifier
                                                .clickable { showFullTraceback = !showFullTraceback }
                                                .padding(vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (showFullTraceback) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                                contentDescription = null,
                                                tint = DarkOnSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (showFullTraceback) "Hide full traceback" else "View full traceback",
                                                fontSize = 11.sp,
                                                color = DarkOnSurfaceVariant
                                            )
                                        }

                                        AnimatedVisibility(visible = showFullTraceback) {
                                            Text(
                                                text = result.stderr,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                color = ConsoleStderr,
                                                lineHeight = 16.sp,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(DarkBackground, RoundedCornerShape(6.dp))
                                                    .padding(8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            is ExecutionResult.RuntimeNotConfigured -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = ConsoleWarning,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Runtime Notice: ${result.engineName}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = ConsoleWarning
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = result.reason,
                                            fontSize = 12.sp,
                                            color = DarkOnSurface
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = result.setupInstructions,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            color = DarkOnSurfaceVariant
                                        )
                                    }
                                }
                            }
                            is ExecutionResult.Running -> {
                                // Handled in loading state above
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(result: ExecutionResult, isExecuting: Boolean) {
    val (label, bg, fg) = when {
        isExecuting -> Triple("RUNNING", ConsoleWarning.copy(alpha = 0.2f), ConsoleWarning)
        result is ExecutionResult.Success -> Triple("SUCCESS", ConsoleSuccess.copy(alpha = 0.2f), ConsoleSuccess)
        result is ExecutionResult.Error -> Triple("ERROR", ConsoleStderr.copy(alpha = 0.2f), ConsoleStderr)
        result is ExecutionResult.RuntimeNotConfigured -> Triple("UNCONFIGURED", ConsoleWarning.copy(alpha = 0.2f), ConsoleWarning)
        else -> Triple("IDLE", DarkSurfaceVariant, DarkOnSurfaceVariant)
    }

    Surface(
        shape = RoundedCornerShape(4.dp),
        color = bg
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
