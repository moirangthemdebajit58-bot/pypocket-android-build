package com.pypocket.app.engine

import android.content.Context
import android.util.Log
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Concrete Android implementation using the Chaquopy embedded CPython engine.
 *
 * Genuine execution pipeline:
 * 1. Ensures Python runtime is initialized via [AndroidPlatform].
 * 2. Invokes `pypocket_runner.run_code(code)` in an isolated Python namespace.
 * 3. Captures real stdout, stderr, exit codes, and execution duration.
 * 4. Captures genuine SyntaxError and runtime tracebacks.
 * 5. Returns [ExecutionResult.Success], [ExecutionResult.Error], or [ExecutionResult.RuntimeNotConfigured].
 */
class ChaquopyExecutionEngine(
    private val context: Context,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) : PythonExecutionEngine {

    override val engineName: String = "Chaquopy Embedded Python 3.11"

    override val isRuntimeReady: Boolean
        get() = try {
            Python.isStarted()
        } catch (e: Throwable) {
            false
        }

    private val _executionState = MutableStateFlow<ExecutionResult>(ExecutionResult.Idle)
    override val executionState: StateFlow<ExecutionResult> = _executionState.asStateFlow()

    private fun ensurePythonStarted(): Boolean {
        return try {
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(context.applicationContext))
            }
            Python.isStarted()
        } catch (e: Throwable) {
            Log.e("ChaquopyEngine", "Failed to start Chaquopy Python runtime: ${e.message}", e)
            false
        }
    }

    override suspend fun execute(code: String): ExecutionResult = withContext(dispatcher) {
        _executionState.value = ExecutionResult.Running

        // Validate empty input early
        if (code.isBlank()) {
            val emptyResult = ExecutionResult.Error(
                stderr = "PyPocket Notice: Cannot execute an empty script. Please write some Python code first.",
                errorType = "EmptyInputError",
                executionTimeMs = 0
            )
            _executionState.value = emptyResult
            return@withContext emptyResult
        }

        val started = ensurePythonStarted()
        if (!started) {
            val unconfigured = ExecutionResult.RuntimeNotConfigured(
                engineName = engineName,
                reason = "Chaquopy embedded CPython runtime could not be started or native libraries are missing.",
                setupInstructions = """
                    To run Python natively on your Android device:
                    1. Sync the project with Gradle in Android Studio or build with GitHub Actions.
                    2. Ensure Chaquopy plugin is enabled and abiFilters match your device (arm64-v8a).
                    3. Install the APK on an Android device or emulator with API 26+.
                """.trimIndent()
            )
            _executionState.value = unconfigured
            return@withContext unconfigured
        }

        try {
            val pyInstance = Python.getInstance()
            val runnerModule: PyObject = pyInstance.getModule("pypocket_runner")

            // Invoke pypocket_runner.run_code(code)
            val resultPyObject: PyObject = runnerModule.callAttr("run_code", code)
                ?: throw IllegalStateException("pypocket_runner.run_code returned null")

            // Extract map items from returned Python dictionary
            val stdout = resultPyObject.callAttr("get", "stdout")?.toString() ?: ""
            val stderr = resultPyObject.callAttr("get", "stderr")?.toString() ?: ""
            val exitCode = resultPyObject.callAttr("get", "exit_code")?.toString()?.toIntOrNull() ?: 0
            val durationMs = resultPyObject.callAttr("get", "duration_ms")?.toString()?.toLongOrNull() ?: 0L
            val hasError = resultPyObject.callAttr("get", "has_error")?.toString()?.toBooleanStrictOrNull() ?: false

            val finalResult = if (hasError || exitCode != 0 || stderr.isNotBlank()) {
                val errType = when {
                    stderr.contains("SyntaxError") -> "SyntaxError"
                    stderr.contains("IndentationError") -> "IndentationError"
                    stderr.contains("ZeroDivisionError") -> "ZeroDivisionError"
                    stderr.contains("NameError") -> "NameError"
                    stderr.contains("TypeError") -> "TypeError"
                    else -> "RuntimeError"
                }
                ExecutionResult.Error(
                    stderr = stderr.ifBlank { "Execution finished with exit code $exitCode" },
                    errorType = errType,
                    executionTimeMs = durationMs
                )
            } else {
                ExecutionResult.Success(
                    stdout = stdout,
                    executionTimeMs = durationMs,
                    exitCode = exitCode
                )
            }

            _executionState.value = finalResult
            finalResult

        } catch (e: Throwable) {
            val rootCause = e.cause ?: e
            val errorMessage = rootCause.localizedMessage ?: rootCause.message ?: "Python Execution Error"

            val errorResult = ExecutionResult.Error(
                stderr = errorMessage,
                errorType = rootCause.javaClass.simpleName,
                executionTimeMs = 0
            )
            _executionState.value = errorResult
            errorResult
        }
    }

    override fun resetConsole() {
        _executionState.value = ExecutionResult.Idle
    }
}
