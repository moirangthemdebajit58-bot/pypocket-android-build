package com.pypocket.app.data.model

object ExamplePrograms {
    val helloWorld = PythonProgram(
        id = "example_hello_world",
        title = "Hello World",
        description = "Classic introductory script with greetings and formatted strings",
        code = """# Welcome to PyPocket!
# The mobile-first Python editor

def greet(name: str) -> str:
    return f"Hello, {name}! Welcome to Python on mobile."

print(greet("Explorer"))
print("-" * 30)

languages = ["Python", "Kotlin", "Compose"]
for index, lang in enumerate(languages, start=1):
    print(f"{index}. Learning {lang}")

print("\nReady to code anywhere!")
""".trimIndent(),
        createdAt = 1700000000000L,
        updatedAt = 1700000000000L
    )

    val calculator = PythonProgram(
        id = "example_calculator",
        title = "Pocket Calculator",
        description = "Arithmetic helper functions with inputs, results, and summary formatting",
        code = """# Simple Pocket Calculator Functions

def add(a, b): return a + b
def subtract(a, b): return a - b
def multiply(a, b): return a * b
def divide(a, b):
    if b == 0:
        return "Error: Division by zero"
    return a / b

# Sample Calculations
x, y = 24, 7

print(f"Inputs: x = {x}, y = {y}")
print(f"Addition:       {x} + {y} = {add(x, y)}")
print(f"Subtraction:    {x} - {y} = {subtract(x, y)}")
print(f"Multiplication: {x} * {y} = {multiply(x, y)}")
print(f"Division:       {x} / {y} = {divide(x, y):.4f}")
print(f"Power:          {x} ** 2 = {x ** 2}")
""".trimIndent(),
        createdAt = 1700000100000L,
        updatedAt = 1700000100000L
    )

    val multiplicationTable = PythonProgram(
        id = "example_multiplication_table",
        title = "Multiplication Table",
        description = "Generates a clean multiplication matrix using nested loops",
        code = """# Multiplication Table Generator

def generate_table(number: int, up_to: int = 10):
    print(f"=== Table of {number} ===")
    for i in range(1, up_to + 1):
        product = number * i
        print(f"{number:>2} x {i:>2} = {product:>3}")
    print()

# Generate tables for 5, 7, and 9
for n in [5, 7, 9]:
    generate_table(n, 8)
""".trimIndent(),
        createdAt = 1700000200000L,
        updatedAt = 1700000200000L
    )

    val all: List<PythonProgram> = listOf(helloWorld, calculator, multiplicationTable)
}
