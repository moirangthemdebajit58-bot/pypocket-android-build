package com.pypocket.app.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.pypocket.app.data.model.PythonProgram
import com.pypocket.app.data.repository.ProgramRepository
import com.pypocket.app.engine.ExecutionResult
import com.pypocket.app.engine.PythonExecutionEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class EditorUiState(
    val isLoading: Boolean = true,
    val program: PythonProgram? = null,
    val code: String = "",
    val title: String = "",
    val isDirty: Boolean = false,
    val isConsoleOpen: Boolean = false,
    val isExecuting: Boolean = false,
    val executionResult: ExecutionResult = ExecutionResult.Idle,
    val errorMessage: String? = null,
    val toastMessage: String? = null
)

class EditorViewModel(
    private val programId: String,
    private val repository: ProgramRepository,
    private val executionEngine: PythonExecutionEngine
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    init {
        loadProgram()
        observeExecutionEngine()
    }

    private fun loadProgram() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val prog = repository.getProgramById(programId)
            if (prog != null) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    program = prog,
                    code = prog.code,
                    title = prog.title,
                    isDirty = false
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Program not found"
                )
            }
        }
    }

    private fun observeExecutionEngine() {
        viewModelScope.launch {
            executionEngine.executionState.collect { result ->
                _uiState.value = _uiState.value.copy(
                    executionResult = result,
                    isExecuting = result is ExecutionResult.Running
                )
            }
        }
    }

    fun onCodeChange(newCode: String) {
        _uiState.value = _uiState.value.copy(
            code = newCode,
            isDirty = true
        )
    }

    fun onTitleChange(newTitle: String) {
        _uiState.value = _uiState.value.copy(
            title = newTitle,
            isDirty = true
        )
    }

    fun insertTextAtSelection(
        currentText: String,
        selectionStart: Int,
        selectionEnd: Int,
        textToInsert: String
    ): Pair<String, Int> {
        val safeStart = selectionStart.coerceIn(0, currentText.length)
        val safeEnd = selectionEnd.coerceIn(safeStart, currentText.length)
        val newText = currentText.substring(0, safeStart) + textToInsert + currentText.substring(safeEnd)
        val newCursor = safeStart + textToInsert.length
        onCodeChange(newText)
        return Pair(newText, newCursor)
    }

    fun insertIndentation(currentText: String, cursorIndex: Int): Pair<String, Int> {
        return insertTextAtSelection(currentText, cursorIndex, cursorIndex, "    ")
    }

    fun saveProgram() {
        val currentState = _uiState.value
        val original = currentState.program ?: return
        viewModelScope.launch {
            val updated = original.copy(
                title = currentState.title.ifBlank { "Untitled Script" },
                code = currentState.code,
                updatedAt = System.currentTimeMillis()
            )
            repository.saveProgram(updated)
            _uiState.value = _uiState.value.copy(
                program = updated,
                isDirty = false,
                toastMessage = "Program saved locally"
            )
        }
    }

    fun runCode() {
        val currentCode = _uiState.value.code
        if (currentCode.isBlank()) {
            _uiState.value = _uiState.value.copy(
                isConsoleOpen = true,
                executionResult = ExecutionResult.Error(
                    stderr = "PyPocket: Cannot execute empty script. Please write some Python code first.",
                    errorType = "EmptyInputError",
                    executionTimeMs = 0
                )
            )
            return
        }

        // Save current modifications before running
        saveProgram()
        _uiState.value = _uiState.value.copy(isConsoleOpen = true)
        viewModelScope.launch {
            executionEngine.execute(currentCode)
        }
    }

    fun clearConsole() {
        executionEngine.resetConsole()
        _uiState.value = _uiState.value.copy(
            executionResult = ExecutionResult.Idle
        )
    }

    fun setConsoleOpen(isOpen: Boolean) {
        _uiState.value = _uiState.value.copy(isConsoleOpen = isOpen)
    }

    fun clearToast() {
        _uiState.value = _uiState.value.copy(toastMessage = null)
    }

    companion object {
        fun provideFactory(
            programId: String,
            repository: ProgramRepository,
            executionEngine: PythonExecutionEngine
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return EditorViewModel(programId, repository, executionEngine) as T
            }
        }
    }
}
