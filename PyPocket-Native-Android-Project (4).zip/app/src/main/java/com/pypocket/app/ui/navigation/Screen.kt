package com.pypocket.app.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Editor : Screen("editor/{programId}") {
        fun createRoute(programId: String): String = "editor/$programId"
    }
}
