package com.pypocket.app.data.repository

import android.content.Context
import com.pypocket.app.data.model.ExamplePrograms
import com.pypocket.app.data.model.PythonProgram
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Local JSON file-based repository that persists programs in internal app storage.
 * Seeds example programs on initial run.
 */
class FileProgramRepository(
    private val context: Context,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ProgramRepository {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    private val storageFile: File by lazy {
        File(context.filesDir, "pypocket_programs.json")
    }

    private val _programsFlow = MutableStateFlow<List<PythonProgram>>(emptyList())

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        if (!storageFile.exists()) {
            val defaults = ExamplePrograms.all
            saveToFile(defaults)
            _programsFlow.value = defaults
        } else {
            try {
                val content = storageFile.readText()
                val list = json.decodeFromString<List<PythonProgram>>(content)
                _programsFlow.value = list
            } catch (e: Exception) {
                // Graceful fallback to example programs if file is corrupted
                _programsFlow.value = ExamplePrograms.all
            }
        }
    }

    override fun getAllPrograms(): Flow<List<PythonProgram>> = _programsFlow.asStateFlow()

    override suspend fun getProgramById(id: String): PythonProgram? = withContext(ioDispatcher) {
        _programsFlow.value.find { it.id == id }
    }

    override suspend fun saveProgram(program: PythonProgram): Result<Unit> = withContext(ioDispatcher) {
        try {
            val current = _programsFlow.value.toMutableList()
            val existingIndex = current.indexOfFirst { it.id == program.id }
            val updatedProgram = program.copy(updatedAt = System.currentTimeMillis())

            if (existingIndex >= 0) {
                current[existingIndex] = updatedProgram
            } else {
                current.add(0, updatedProgram)
            }

            saveToFile(current)
            _programsFlow.value = current
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteProgram(id: String): Result<Unit> = withContext(ioDispatcher) {
        try {
            val current = _programsFlow.value.toMutableList()
            val removed = current.removeAll { it.id == id }
            if (removed) {
                saveToFile(current)
                _programsFlow.value = current
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun duplicateProgram(id: String): Result<PythonProgram> = withContext(ioDispatcher) {
        try {
            val existing = _programsFlow.value.find { it.id == id }
                ?: return@withContext Result.failure(IllegalArgumentException("Program not found"))

            val duplicated = existing.copy(
                id = "prog_${System.currentTimeMillis()}",
                title = "${existing.title} (Copy)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val current = _programsFlow.value.toMutableList()
            current.add(0, duplicated)
            saveToFile(current)
            _programsFlow.value = current
            Result.success(duplicated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun saveToFile(list: List<PythonProgram>) {
        val serialized = json.encodeToString(list)
        storageFile.writeText(serialized)
    }
}
