package com.pypocket.app.engine

import kotlinx.coroutines.flow.StateFlow

/**
 * Clean architectural abstraction for running Python code.
 * Implementations can be Chaquopy, Pyodide WebAssembly, Python C-API JNI,
 * or an unconfigured placeholder when no native runtime library is bundled.
 */
interface PythonExecutionEngine {
    val engineName: String
    val isRuntimeReady: Boolean
    val executionState: StateFlow<ExecutionResult>

    /**
     * Executes the provided Python script.
     * Implementations MUST NOT fabricate synthetic outputs.
     */
    suspend fun execute(code: String): ExecutionResult

    /**
     * Clears previous execution results and resets stdout/stderr buffers.
     */
    fun resetConsole()
}
