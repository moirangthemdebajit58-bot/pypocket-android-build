"""
PyPocket Embedded Python Runner Module
Executed inside Chaquopy / CPython embedded on Android.
"""
import sys
import io
import time
import traceback

def run_code(code_str: str) -> dict:
    """
    Executes user Python code and captures genuine stdout, stderr, and tracebacks.
    Returns a dictionary of execution results.
    """
    if not code_str or not code_str.strip():
        return {
            "stdout": "",
            "stderr": "PyPocket: Empty code submitted. Please write Python code to execute.",
            "exit_code": 1,
            "duration_ms": 0,
            "has_error": True,
            "error_type": "EmptyInputError"
        }

    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    sys.stdout = stdout_capture
    sys.stderr = stderr_capture

    start_time = time.perf_counter()
    error_traceback = None
    error_type = None
    exit_code = 0

    try:
        # Compile first to separate syntax errors from runtime exceptions
        compiled = compile(code_str, "<pypocket_script>", "exec")
        
        # Isolate execution namespace
        global_namespace = {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
        }
        exec(compiled, global_namespace)

    except SystemExit as se:
        # User called sys.exit()
        exit_code = se.code if isinstance(se.code, int) else 0

    except SyntaxError as syn_err:
        exit_code = 1
        error_type = "SyntaxError"
        error_traceback = "".join(traceback.format_exception_only(type(syn_err), syn_err)).strip()

    except Exception as exc:
        exit_code = 1
        error_type = type(exc).__name__
        # Clean traceback removing internal runner frames
        error_traceback = traceback.format_exc().strip()

    except BaseException as base_exc:
        exit_code = 1
        error_type = type(base_exc).__name__
        error_traceback = traceback.format_exc().strip()

    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        duration_ms = int((time.perf_counter() - start_time) * 1000)

    captured_stdout = stdout_capture.getvalue()
    captured_stderr = stderr_capture.getvalue()

    combined_stderr = ""
    if error_traceback:
        combined_stderr = error_traceback
        if captured_stderr:
            combined_stderr += "\n" + captured_stderr
    else:
        combined_stderr = captured_stderr

    return {
        "stdout": captured_stdout,
        "stderr": combined_stderr,
        "exit_code": exit_code,
        "duration_ms": duration_ms,
        "has_error": exit_code != 0 or bool(combined_stderr),
        "error_type": error_type or ""
    }
