package com.pypocket.app

import com.pypocket.app.data.model.ExamplePrograms
import com.pypocket.app.data.model.PythonProgram
import com.pypocket.app.data.repository.ProgramRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

/**
 * Unit tests verifying program CRUD operations and duplication logic.
 */
class ProgramRepositoryTest {

    private lateinit var repository: FakeProgramRepository

    @Before
    fun setUp() {
        repository = FakeProgramRepository()
    }

    @Test
    fun defaultExamples_areLoadedSuccessfully() = runBlocking {
        val programs = repository.getAllList()
        assertEquals(3, programs.size)
        assertEquals("Hello World", programs[0].title)
    }

    @Test
    fun saveProgram_createsAndUpdatesCorrectly() = runBlocking {
        val newProgram = PythonProgram(
            id = "test_1",
            title = "Fibonacci Generator",
            code = "def fib(n): pass"
        )
        repository.saveProgram(newProgram)

        val retrieved = repository.getProgramById("test_1")
        assertNotNull(retrieved)
        assertEquals("Fibonacci Generator", retrieved?.title)

        // Update
        val updated = retrieved!!.copy(title = "Fibonacci Generator V2")
        repository.saveProgram(updated)

        val retrievedUpdated = repository.getProgramById("test_1")
        assertEquals("Fibonacci Generator V2", retrievedUpdated?.title)
    }

    @Test
    fun duplicateProgram_createsDistinctCopy() = runBlocking {
        val original = repository.getProgramById("example_hello_world")
        assertNotNull(original)

        val duplicateResult = repository.duplicateProgram("example_hello_world")
        val copy = duplicateResult.getOrThrow()

        assertEquals("Hello World (Copy)", copy.title)
        assertEquals(original!!.code, copy.code)
        assert(copy.id != original.id)
    }

    @Test
    fun deleteProgram_removesFromRepository() = runBlocking {
        repository.deleteProgram("example_calculator")
        val deleted = repository.getProgramById("example_calculator")
        assertEquals(null, deleted)
    }
}

/**
 * In-memory test double of [ProgramRepository].
 */
class FakeProgramRepository : ProgramRepository {
    private val state = MutableStateFlow(ExamplePrograms.all.toMutableList())

    suspend fun getAllList(): List<PythonProgram> = state.value

    override fun getAllPrograms(): Flow<List<PythonProgram>> = state.asStateFlow()

    override suspend fun getProgramById(id: String): PythonProgram? {
        return state.value.find { it.id == id }
    }

    override suspend fun saveProgram(program: PythonProgram): Result<Unit> {
        val current = state.value.toMutableList()
        val index = current.indexOfFirst { it.id == program.id }
        if (index >= 0) {
            current[index] = program
        } else {
            current.add(0, program)
        }
        state.value = current
        return Result.success(Unit)
    }

    override suspend fun deleteProgram(id: String): Result<Unit> {
        val current = state.value.toMutableList()
        current.removeAll { it.id == id }
        state.value = current
        return Result.success(Unit)
    }

    override suspend fun duplicateProgram(id: String): Result<PythonProgram> {
        val existing = getProgramById(id) ?: return Result.failure(Exception("Not found"))
        val copy = existing.copy(
            id = "copy_${System.currentTimeMillis()}",
            title = "${existing.title} (Copy)"
        )
        val current = state.value.toMutableList()
        current.add(0, copy)
        state.value = current
        return Result.success(copy)
    }
}
