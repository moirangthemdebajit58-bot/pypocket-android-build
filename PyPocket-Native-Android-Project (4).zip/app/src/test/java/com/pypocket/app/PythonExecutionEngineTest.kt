package com.pypocket.app

import com.pypocket.app.engine.ChaquopyExecutionEngine
import com.pypocket.app.engine.ExecutionResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests verifying compliance with Engineering Rules:
 * - Empty code submissions are validated cleanly without executing.
 * - When native runtime libraries are absent on the JVM classpath,
 *   [ExecutionResult.RuntimeNotConfigured] is returned without fabricating results.
 */
class PythonExecutionEngineTest {

    @Test
    fun emptyCode_returnsEmptyInputErrorImmediately() = runBlocking {
        val engine = ChaquopyExecutionEngine(
            context = android.test.mock.MockContext()
        )

        val result = engine.execute("   ")
        assertTrue("Execution of blank code must return Error", result is ExecutionResult.Error)

        val error = result as ExecutionResult.Error
        assertEquals("EmptyInputError", error.errorType)
        assertTrue(error.stderr.contains("Cannot execute an empty script"))
    }

    @Test
    fun unconfiguredEngine_returnsRuntimeNotConfiguredWithoutFakingOutput() = runBlocking {
        val engine = ChaquopyExecutionEngine(
            context = android.test.mock.MockContext()
        )

        val result = engine.execute("print('Hello from PyPocket')")

        // Without Chaquopy CPython library in test classpath, isRuntimeReady must be false
        assertTrue("Execution must be RuntimeNotConfigured", result is ExecutionResult.RuntimeNotConfigured)

        val unconfigured = result as ExecutionResult.RuntimeNotConfigured
        assertTrue(unconfigured.reason.contains("Chaquopy embedded CPython"))
        assertTrue(unconfigured.setupInstructions.contains("Android Studio"))
    }
}
