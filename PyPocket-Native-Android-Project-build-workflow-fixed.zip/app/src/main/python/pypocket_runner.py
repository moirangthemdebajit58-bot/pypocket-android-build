"""
PyPocket Embedded Python Runner Module
Executed inside Chaquopy / CPython embedded on Android.
Upgraded to support multi-file project directories, input interception, and Matplotlib chart exports.
"""
import sys
import io
import os
import time
import json
import traceback
import builtins

def run_code(code_str: str, project_files_json: str = "[]", stdin_inputs_json: str = "[]") -> dict:
    """
    Executes user Python code and captures genuine stdout, stderr, tracebacks, and plots.
    Supports multi-file projects through project_files_json and pre-queued stdin inputs.
    """
    if not code_str or not code_str.strip():
        return {
            "stdout": "",
            "stderr": "PyPocket: Empty code submitted. Please write Python code to execute.",
            "exit_code": 1,
            "duration_ms": 0,
            "has_error": True,
            "error_type": "EmptyInputError",
            "plots": []
        }

    # Parse project files and mount into a temporary working directory
    working_dir = None
    try:
        files = json.loads(project_files_json) if isinstance(project_files_json, str) else project_files_json
        if files:
            import tempfile
            working_dir = tempfile.mkdtemp(prefix="pypocket_run_")
            sys.path.insert(0, working_dir)
            for f in files:
                name = f.get("name")
                content = f.get("content", "")
                if name:
                    file_path = os.path.join(working_dir, name)
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    with open(file_path, "w", encoding="utf-8") as wf:
                        wf.write(content)
    except Exception as mount_err:
        pass

    # Parse queued inputs
    input_queue = []
    try:
        input_queue = json.loads(stdin_inputs_json) if isinstance(stdin_inputs_json, str) else list(stdin_inputs_json)
    except Exception:
        input_queue = []

    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_input = builtins.input

    sys.stdout = stdout_capture
    sys.stderr = stderr_capture

    # Input bridge
    def _custom_input(prompt=""):
        if prompt:
            stdout_capture.write(str(prompt))
            stdout_capture.flush()
        if input_queue:
            val = str(input_queue.pop(0))
            stdout_capture.write(val + "\n")
            return val
        return ""

    builtins.input = _custom_input

    captured_plots = []
    # Matplotlib plot interceptor
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import base64

        def _custom_show(*args, **kwargs):
            buf = io.BytesIO()
            plt.savefig(buf, format="png", bbox_inches="tight", dpi=100)
            buf.seek(0)
            b64 = base64.b64encode(buf.read()).decode("ascii")
            captured_plots.append("data:image/png;base64," + b64)
            plt.close("all")

        plt.show = _custom_show
    except Exception:
        pass

    start_time = time.perf_counter()
    error_traceback = None
    error_type = None
    exit_code = 0

    try:
        compiled = compile(code_str, "<pypocket_script>", "exec")
        global_namespace = {
            "__name__": "__main__",
            "__doc__": None,
            "__package__": None,
        }
        exec(compiled, global_namespace)

    except SystemExit as se:
        exit_code = se.code if isinstance(se.code, int) else 0

    except SyntaxError as syn_err:
        exit_code = 1
        error_type = "SyntaxError"
        error_traceback = "".join(traceback.format_exception_only(type(syn_err), syn_err)).strip()

    except Exception as exc:
        exit_code = 1
        error_type = type(exc).__name__
        error_traceback = traceback.format_exc().strip()

    except BaseException as base_exc:
        exit_code = 1
        error_type = type(base_exc).__name__
        error_traceback = traceback.format_exc().strip()

    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        builtins.input = old_input
        if working_dir and working_dir in sys.path:
            sys.path.remove(working_dir)
        duration_ms = int((time.perf_counter() - start_time) * 1000)

    captured_stdout = stdout_capture.getvalue()
    captured_stderr = stderr_capture.getvalue()

    combined_stderr = ""
    if error_traceback:
        combined_stderr = error_traceback
        if captured_stderr:
            combined_stderr += "\n" + captured_stderr
    else:
        combined_stderr = captured_stderr

    return {
        "stdout": captured_stdout,
        "stderr": combined_stderr,
        "exit_code": exit_code,
        "duration_ms": duration_ms,
        "has_error": exit_code != 0 or bool(combined_stderr),
        "error_type": error_type or "",
        "plots": captured_plots
    }
