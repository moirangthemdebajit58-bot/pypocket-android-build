package com.pypocket.app.data.model

import kotlinx.serialization.Serializable

/**
 * Represents an individual file within a multi-file Python project.
 */
@Serializable
data class ProjectFile(
    val name: String,
    val content: String,
    val isEntry: Boolean = false,
    val type: String = "python"
)

/**
 * Represents a saved or in-memory Python project document.
 */
@Serializable
data class PythonProgram(
    val id: String,
    val title: String,
    val code: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val description: String = "",
    val category: String = "fundamentals",
    val activeFileName: String = "main.py",
    val files: List<ProjectFile> = emptyList()
) {
    val lineCount: Int
        get() = code.split("\n").size
}
