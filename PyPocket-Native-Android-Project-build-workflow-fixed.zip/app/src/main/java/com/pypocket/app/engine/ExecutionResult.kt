package com.pypocket.app.engine

/**
 * Result model representing the outcome of a Python execution attempt.
 */
sealed class ExecutionResult {
    data class Success(
        val stdout: String,
        val executionTimeMs: Long,
        val exitCode: Int = 0,
        val plots: List<String> = emptyList()
    ) : ExecutionResult()

    data class Error(
        val stderr: String,
        val errorType: String,
        val line: Int? = null,
        val executionTimeMs: Long = 0,
        val plots: List<String> = emptyList()
    ) : ExecutionResult()

    data class RuntimeNotConfigured(
        val engineName: String,
        val reason: String,
        val setupInstructions: String
    ) : ExecutionResult()

    object Running : ExecutionResult()
    object Idle : ExecutionResult()
}
